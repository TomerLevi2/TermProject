
public interface Acceptable {
	
	public boolean isNonEmptyString(String s);
	public boolean isPositive(int i);
	public boolean isPositiveInput(double d);
}
